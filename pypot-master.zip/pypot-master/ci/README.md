# CI Scripts
These scripts are made for continuous integration. 
They are made as much as possible agnostic of ci platform, and can be used in Travis-ci, Jenkins, AppVeyor, or any other ci software.
